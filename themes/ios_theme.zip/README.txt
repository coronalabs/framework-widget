
HOW TO USE THEMES:
==================

1) Place the theme module (e.g. theme_ios.lua) into your project folder.

2) Place included resource folder into your project folder (e.g. widget_ios/).

3) Use widget.setTheme( moduleFile ) to use the theme. Example:

	local widget = require "widget"
	widget.setTheme( "theme_ios" )

---------------------------------------------------------	

Please see the Widget API Reference before using widgets:
http://developer.anscamobile.com/content/widget